<?php

$conn = mysqli_connect("localhost","myyhospital_user","unix@bali123","myyhospital_1	");


?>