<?php
	
	if (isset($_POST["randevubilgileri"])){
		
		echo $_POST["randevubilgileri"];
	}
	
?>